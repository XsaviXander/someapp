define( function ( require ) {

	"use strict";

	return {
		app_slug : 'rbsgnx-app',
		wp_ws_url : 'https://randmnessbyxx.gq/wp-appkit-api/rbsgnx-app',
		wp_url : 'https://randmnessbyxx.gq',
		theme : 'wpak-theme-bootstrap-feature-user-login',
		version : '1.24.1',
		app_type : 'phonegap-build',
		app_title : 'RBSGNX App',
		app_platform : 'android',
		app_path: '',
		gmt_offset : -4,
		debug_mode : 'off',
		auth_key : 'xTO3l4)@z:M/Z&%f%*mB1b}5pDTX$s0V:N9r-LgqDc3c1ndTXf1sAuJ==G:.G/w!',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
